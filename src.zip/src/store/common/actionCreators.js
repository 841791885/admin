import * as actionTypes from './constants'

export const changeLoadingAction = (loading) => ({
  type: actionTypes.CHANGE_LOADING,
  loading
})
