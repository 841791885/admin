import React, { memo } from 'react'

const Dashboard = memo(() => {
  return <div>Dashboard</div>
})

export default Dashboard
