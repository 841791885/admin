import React, { memo } from 'react'

const Overview = memo(() => {
  return <div>Overview</div>
})

export default Overview
