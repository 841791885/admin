import React, { memo } from 'react'

const Role = memo(() => {
  return <div>Role</div>
})

export default Role
