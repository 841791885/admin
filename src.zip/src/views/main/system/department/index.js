import React, { memo } from 'react'

const Department = memo(() => {
  return <div>department</div>
})

export default Department
