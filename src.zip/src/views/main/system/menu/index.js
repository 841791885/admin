import React, { memo } from 'react'

const Menu = memo(() => {
  return <div>Menu</div>
})

export default Menu
