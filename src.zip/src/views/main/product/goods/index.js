import React, { memo } from 'react'

const Goods = memo(() => {
  return <div>Goods</div>
})

export default Goods
