import React, { memo } from 'react'

const Category = memo(() => {
  return <div>Category</div>
})

export default Category
