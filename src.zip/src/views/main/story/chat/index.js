import React, { memo } from 'react'

const Chat = memo(() => {
  return <div>Chat</div>
})

export default Chat
