import React, { memo } from 'react'

const List = memo(() => {
  return <div>List</div>
})

export default List
