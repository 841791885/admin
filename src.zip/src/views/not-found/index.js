import React, { memo } from 'react'

const NotFound = memo(() => {
  return <div>NotFound</div>
})

export default NotFound
