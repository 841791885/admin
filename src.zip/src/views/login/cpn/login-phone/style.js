import styled from 'styled-components'

export const LoginPhoneWrapper = styled.div`
  .verfiy-code {
    display: flex;
    .get-btn {
      margin-left: 4px;
    }
  }
`
