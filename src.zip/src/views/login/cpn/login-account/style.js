import styled from 'styled-components'

export const LoginAccountWrapper = styled.div``
