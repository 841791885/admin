import styled from 'styled-components'

export const NavInfoWrapper = styled.div`
  .avatar {
    cursor: pointer;
    .name {
      margin-left: 8px;
    }
  }
`
