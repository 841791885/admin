import styled from 'styled-components'

export const BreadCrumbsWrapper = styled.div``
